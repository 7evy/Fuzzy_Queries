#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 11 21:41:32 2020

@author: smits
"""


attributes = ["rent","nbRooms","livingArea","distance2center","gardenArea"]

dataset = [
       [450,4,83,0.6,0],
       [700,5,82,0.5,1],
       [500,3,45,0.1,1],
       [600,3,50,1.7,1],
       [400,5,95,3.5,0],
       [900,7,99,0.8,1],
       [450,3,35,0.1,1],
       [300,2,20,2.1,1],
       [600,2,50,0.7,1],
       [750,4,50,1.1,0]
       ]

conceptExtension = [
        [400,3,40,0.5,0],
        [800,6,99,0.5,0]
        ]


EPSILONS = [0.7,0.9,0.8,0.7,1]
DEBUG=False
DISPLAY=True

#COMPUTE THE RANGES OF EACH DIMENSION
RANGES = [0]*len(dataset[0])
for i in range(0,len(dataset[0])):
    maps = map(lambda x:x[i], dataset)
    ma = max(maps)
    maps = map(lambda x:x[i], dataset)
    mi = min(maps)
    
    RANGES[i] = ma - mi
    
def sim(v1,v2,i):
    return 1 - abs(v2-v1)/RANGES[i]

def muF(H,p,rep):
    mus=[0]*len(rep)
    i=0
    for r in rep:
        for h in H:
            if sim(p[attributes.index(h)],r[attributes.index(h)],attributes.index(h)) >= EPSILONS[attributes.index(h)]:
                mus[i] += 1
        i+=1
    return max(mus)/len(p)

#Pour chaque point
for point in dataset:
    #compute the delta degree of each attribute value
    deltas=dict()
    
    if DEBUG:
        print("\n-***ATTRIBUTES EVALUATION***")
    #COMPUTE THE DELTAS OF EACH VALUE
    if DEBUG : print("- POINT ",point)
    for i in range(len(point)):
        value = point[i]
        deltas[attributes[i]] = 0
        for rep in conceptExtension:
            if sim(value,rep[i],i) >= EPSILONS[i]:
                deltas[attributes[i]]+=1
    for k in deltas:
        deltas[k] = deltas[k] / len(conceptExtension)
    if DEBUG: print("- DELTA ",deltas)

    if DEBUG:
        print("\n-***ATTRIBUTES SORTING***")

    #SORT THE DICT IN DECREASING ORDER OF THE VALUES
    sortedDeltas = sorted(deltas, key=deltas.get,reverse=True)
    if DEBUG :
        print("- SORTED DELTAS ")
        for k in sortedDeltas:
            print(k,"->",deltas[k])
            
    #APPLY THE CHOQUET INTEGRAL
    if DEBUG:
        print("\n-***CHOQUET INTEGRAL***")
    S=0
    mu=0
    for i in range(len(sortedDeltas)):
        mus=[0]*len(conceptExtension)
        Hi = sortedDeltas[:(i+1)]
        Ki = deltas[sortedDeltas[i]]
        muHi = muF(Hi,point,conceptExtension)
        S+=(muHi - mu)*Ki
        if DEBUG :
            print("STEP ",i+1," : ",Hi)
            print("muHi ",muHi ," - mu ",mu, " * Ki ",Ki," : S=",S)
        mu = muHi
            #          
        
    if DISPLAY:
        print("- POINT ",point, " S=",S)