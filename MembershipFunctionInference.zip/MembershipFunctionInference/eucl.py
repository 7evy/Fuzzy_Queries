import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm 
import scipy.stats as st
import scipy.spatial.distance as ssd
import random as rnd
import math
import copy

xmin, xmax = 0, 10
ymin, ymax = 0, 10



def contour_cloud(x, y, cmap):
    xx, yy = np.mgrid[xmin:xmax:100j, ymin:ymax:100j]
    positions = np.vstack([xx.ravel(), yy.ravel()])
    values = np.vstack([x, y])
    kernel = st.gaussian_kde(values)
    f = np.reshape(kernel(positions).T, xx.shape)
    plt.contourf(xx, yy, f, cmap=cmap, alpha=0.5)

def valDist(x,y,n):
    return abs(x-y)/n


def valSim(x,y,n):
    return (n-abs(x-y))/n


def dist(pt,c):
    """
    pt and c are two lists of size 2
    """
    return (valDist(pt[0],c[0],xmax-xmin) + valDist(pt[1],c[1],ymax-ymin))/2

def nnAssign(x,y,cs):
    return min(map(lambda c: dist([x,y],c),cs))


def meannAssign(x,y,cs):    
    return sum(map(lambda c: dist([x,y],c),cs))/len(cs)

def choqAssign2(x,y,cs):
    dx = 0
    dy = 0
    for c in cs:
        dx= max(dx, valSim(x,c[0],xmax-xmin))
        dy= max(dy, valSim(y,c[1],ymax-ymin))

    dxy = 0
    for c in cs:
        #turn to a sim
        vc= (valSim(x,c[0], xmax-xmin) + valSim(y,c[1], ymax-ymin)) /2 
        dxy = max(dxy,vc)
        

    ch = 0
    if dx > dy:
        ch = 1/2 * dx
    else:
        ch = 1/2 * dy
    ch = ch + 1/2 * dxy
#    print("- ITEM [%.1f,%.1f]: dx=%.3f ; dy=%.3f ; dxy=%.3f; CH=%.3f"%(x,y,dx,dy,dxy,ch))
  
    return 1-ch


DEBUG = True
def choqAssign(x,y,cs):

    dx= sum(map(lambda c:valSim(x,c[0],xmax-xmin),cs))/len(cs)
    dy= sum(map(lambda c:valSim(y,c[1],ymax-ymin),cs))/len(cs)

    dxy = 0
    for c in cs:
        #turn to a sim
        vc= (valSim(x,c[0], xmax-xmin) + valSim(y,c[1], ymax-ymin)) /2 
        dxy = max(dxy,vc)
        

    ch = 0
    if dx > dy:
        ch = 1/2 * dx
    else:
        ch = 1/2 * dy
    ch = ch + 1/2 * dxy
#    print("- ITEM [%.1f,%.1f]: dx=%.3f ; dy=%.3f ; dxy=%.3f; CH=%.3f"%(x,y,dx,dy,dxy,ch))
  
    return 1-ch

# Assuming to have 2 clusters, split the points into two subsets
#representative_1a = [rnd.randrange(xmin,xmax),rnd.randrange(ymin,ymax)]
#representative_2a = [rnd.randrange(xmin,xmax),rnd.randrange(ymin,ymax)]
#representative_3a = [rnd.randrange(xmin,xmax),rnd.randrange(ymin,ymax)]
representative_1a = [2,2]
representative_2a = [2,9]
representative_3a = [8,6]
representative_4a = [2.5,8.5]
representative_5a = [2,8]

centers=[representative_1a,representative_2a,representative_3a,representative_4a,representative_5a]
centers =[[2,2],
          [2,9],
          [8,6],
          [2.5,8.5],
          [2,8],
          [2,8.75],
          [2.25,8.25],
          [2.25,8.5]
        ]
cluster_1 = []
cluster_2 = []
cluster_3 = []


if False:
    """
    Test ALL surface

    Closest neightbor assignment
    """

    x = np.linspace(-3, 15, 50)
    y = np.linspace(-3, 15, 50)
    X, Y = np.meshgrid(x, y)
    Z = X+Y # calcul du tableau des valeurs de Z
    for i in range(len(Z)):
        for j in range(len(Z[0])):
            Z[i][j] = nnAssign(X[i][j],Y[i][j],centers)
    

    plt.pcolormesh(X, Y, Z, shading="gouraud",cmap=plt.cm.hot,vmax=0.6,alpha=0.8)
#    plt.colorbar()
    for c in centers:
        plt.scatter(x=c[0], y=c[1], c='w')
    
    plt.show()
      
    """
    Mean Assignment
    """
    for i in range(len(Z)):
       for j in range(len(Z[0])):
           Z[i][j] = meannAssign(X[i][j],Y[i][j],centers)
    

    plt.pcolormesh(X, Y, Z, shading="gouraud",cmap=plt.cm.hot,vmax=0.6,alpha=0.8)
   
    for c in centers:
        plt.scatter(x=c[0], y=c[1], c='w')
    
    plt.show()
    
       
    """
    Choquet Assignment
    """
    for i in range(len(Z)):
       for j in range(len(Z[0])):
           Z[i][j] = choqAssign(X[i][j],Y[i][j],centers)
    

    plt.pcolormesh(X, Y, Z, shading="gouraud",cmap=plt.cm.hot,vmax=0.6,alpha=0.8)
    for c in centers:
        plt.scatter(x=c[0], y=c[1], c='w')
    
    plt.show()

#MIN NN
if False:
    th = 0.12
    #plt.subplot(3, 1, 1)
    axes = plt.gca()
    axes.set_xlim(xmin, xmax)
    axes.set_ylim(ymin, ymax)
    meth="NN"#
    for xv in np.arange(xmin,xmax,0.5):
        for yv in np.arange(ymin, ymax,0.5):
            deg = nnAssign(xv,yv,centers)
            if deg <= th:
                plt.scatter(x=xv, y=yv, c='black',alpha=(th-deg)/th)



    for c in centers:
        plt.scatter(x=c[0], y=c[1], c='black',marker='D')
    
    plt.show()

#MEAN NN

if False:
    th=0.23
   # plt.subplot(3, 1, 2)
    axes = plt.gca()
    axes.set_xlim(xmin, xmax)
    axes.set_ylim(ymin, ymax)
    meth="NN"#
    for xv in np.arange(xmin,xmax,0.5):
        for yv in np.arange(ymin, ymax,0.5):
            deg = meannAssign(xv,yv,centers)
            if deg <= th:
                #print("V = %f in ->%f"%(deg,(th-deg)/th))
                plt.scatter(x=xv, y=yv, c='black',alpha=(th-deg)/th)


    for c in centers:
        plt.scatter(x=c[0], y=c[1], c='black',marker='D')
    
    plt.show()


#CHOD NN
if True:
 #   plt.subplot(3, 1, 3)
    axes = plt.gca()
    axes.set_xlim(xmin, xmax)
    axes.set_ylim(ymin, ymax)

    th=0.1
    meth="NN"#
    for xv in np.arange(xmin,xmax,0.5):
        for yv in np.arange(ymin, ymax,0.5):
            deg = choqAssign2(xv,yv,centers)
            if deg <= th:
                plt.scatter(x=xv, y=yv, c='black',alpha=(th-deg)/th)


    for c in centers:
        plt.scatter(x=c[0], y=c[1], c='black',marker='D')
    
    plt.show()

"""
plt.subplot(3, 1, 3)
plt.scatter(x=representative_1[0], y=representative_1[1], c='b')
plt.scatter(x=representative_2[0], y=representative_2[1], c='b')
plt.scatter(x=representative_3[0], y=representative_3[1], c='b')
contour_cloud(x=[a[0][0] for a in cluster_3], y=[a[0][1] for a in cluster_3], cmap=cm.Blues)
"""
