#!/usr/local/bin/python3
from random import *
import math
import sys
# This import registers the 3D projection, but is otherwise unused.
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401 unused import

import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
import numpy as np
import copy

DIMX=5
DIMY=5
NBCENTERS=3
CENTERS=[]
SIMMAT=np.arange(DIMX*DIMY).reshape(DIMX,DIMY)

print(SIMMAT)

def euclideanDistance(p1,p2):
    a = abs(p1[0] - p2[0])/DIMX
    b = abs(p1[1] - p2[1])/DIMY
    return (a+b)/2



def display():
    fig = plt.figure()
    ax = fig.gca(projection='3d')

    X = np.arange(0, DIMX, 1)
    Y = np.arange(0, DIMY, 1)
    X, Y = np.meshgrid(X, Y) 

   

  
 
    surf = ax.plot_surface(X, Y, SIMMAT, cmap=cm.coolwarm,
                        linewidth=0, antialiased=False)

    # Customize the z axis.
    ax.set_zlim(-0.01, 1.01)
    ax.zaxis.set_major_locator(LinearLocator(10))
    ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

    # Add a color bar which maps values to colors.
    fig.colorbar(surf, shrink=0.5, aspect=5)

    plt.show()

if __name__ == "__main__":
    #Random generation of the centers
    seed()
    for i in range(NBCENTERS):
        CENTERS.append([randint(0,DIMX),randint(0,DIMY)])


    for x in range(0,DIMX):
        for y in range(0,DIMY):
            pt = [x,y]
            dist=[]
            for c in CENTERS:
                #print("DISTANCE BETWEEN CENTER ",c," AND POINT ",(x,y)," EQUALS ",euclideanDistance([x,y],c))
                dist.append(euclideanDistance([x,y],c))
            SIMMAT[x][y]=min(dist)
            print((x,y),"=>",SIMMAT[x][y])

#            SIMMAT[x][y]=sum(dist)/len(dist)
   

    display()
